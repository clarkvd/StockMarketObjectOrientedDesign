public interface PriceObserver {
	void update(Stock stock);
}
