public abstract class FinancialInstrument {
	public abstract double getValue();
}
