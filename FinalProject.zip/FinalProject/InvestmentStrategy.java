public interface InvestmentStrategy {
	InvestmentStrategy getStrategy();
	String getStrategyName();
}
